package com.common;
/*
 * author: xstahl01
 * Record to represent a position in the grid.
 */

public record Position(int row, int col) {
}
