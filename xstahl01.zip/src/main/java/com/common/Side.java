package com.common;
/*
 * author: xstahl01
 * Enum to represent the four sides of a node in the game.
 */

public enum Side {
    NORTH, WEST, SOUTH, EAST;
}
